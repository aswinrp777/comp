# Yacc calculator
Implementation of Calculator using LEX and YACC

## Algorithm

## Output
```
❯ lex lex.l

❯ yacc -d yacc.y

❯ gcc lex.yy.c y.tab.c -w

❯ ./a.out

Enter arithmetric expression:5+6*7

Result=47

```