# Lex lexical analyzer
Implement a Lexical Analyzer for a given program using Lex Tool.

## Algorithm

## Output

```
❯ lex lexanalyzer.l

❯ gcc lex.yy.c

❯ ./a.out

Enter input. press CTRL+d to stop.

int a=b+5;
keyword Identifier Asssignment_operator Identifier plus Number semicolon

#include<stdio.h>
preprocessor directive

#define A 10
preprocessor directive

int x=90;
keyword Identifier Asssignment_operator Number semicolon

```