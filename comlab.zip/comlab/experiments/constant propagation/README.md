# Constant propagation
Write a program to perform constant propagation.
## Algorithm

## Output
```
❯ gcc constantprop.c

❯ ./a.out


Enter the maximum number of expressions : 4

Enter the input : 
= 5 _ a
+ a a b
* a b c
- c d x

Optimized code is : 
- 50 d x                                                                                                     

```